/*
 * Stream Security — StreamForce custom-plugin GCP entry (Gen2 Cloud Function).
 *
 * Deployed via the terraform-streamsec-google-integration `streamforce-plugin`
 * module as a Gen2 function (Cloud Run under the hood). Gen2 uses the Node
 * functions-framework, so we register an HTTP function named `plugin` (the
 * module's entry_point) and delegate to the customer bundle's Hono `app.fetch`,
 * a Web-standard (Request) => Promise<Response> handler.
 *
 * Env: the customer's values arrive as a single JSON env var (PLUGIN_ENV_JSON,
 * set by the Terraform module) — expanded into process.env at cold start
 * (mirrors AWS PluginEnv / Azure app settings). The platform x-api-key is
 * fetched once from the config callback (authenticated by the plugin token),
 * never baked into the deploy. Inbound auth is enforced by Cloud Run IAM
 * (run.invoker + an OIDC id_token); the app-layer x-api-key check lives inside
 * the customer's Hono app, exactly as on AWS/Azure.
 */

const functions = require('@google-cloud/functions-framework')

// Populated once per container (cold start).
let envLoaded = false
async function loadEnvOnce() {
  if (envLoaded) return
  try {
    const parsed = JSON.parse(process.env.PLUGIN_ENV_JSON || '{}')
    for (const [k, v] of Object.entries(parsed)) {
      if (v !== undefined && v !== null) process.env[k] = String(v)
    }
  } catch (err) {
    // eslint-disable-next-line no-console
    console.error('PLUGIN_ENV_JSON is not valid JSON:', err.message)
  }
  const platformUrl = (process.env.PLATFORM_URL || '').replace(/\/+$/, '')
  const pluginToken = process.env.PLUGIN_TOKEN
  if (platformUrl && pluginToken && !process.env.API_KEY) {
    try {
      const res = await fetch(
        `${platformUrl}/api/accounts/streamforce-plugins/config`,
        { headers: { Authorization: `Bearer ${pluginToken}` } },
      )
      if (res.ok) {
        const body = await res.json()
        const config = body && body.data ? body.data : body
        if (config && config.api_key) process.env.API_KEY = config.api_key
      }
    } catch (err) {
      // eslint-disable-next-line no-console
      console.error('api_key config fetch failed:', err.message)
    }
  }
  envLoaded = true
}

let cachedApp
function getApp() {
  if (!cachedApp) {
    // eslint-disable-next-line global-require
    cachedApp = require('./plugin').app
  }
  return cachedApp
}

// functions-framework hands us an Express-style (req, res). Convert to a Web
// Request, run the Hono app, and write the Web Response back.
function toRequest(req) {
  const headers = new Headers()
  for (const [k, v] of Object.entries(req.headers || {})) {
    if (v !== undefined && v !== null) {
      headers.set(k, Array.isArray(v) ? v.join(', ') : String(v))
    }
  }
  const host = req.headers['x-forwarded-host'] || req.headers.host || 'localhost'
  const proto = req.headers['x-forwarded-proto'] || 'https'
  const url = `${proto}://${host}${req.url || '/'}`
  const method = req.method || 'GET'
  const init = { method, headers }
  if (method !== 'GET' && method !== 'HEAD' && req.rawBody) {
    init.body = req.rawBody
  }
  return new Request(url, init)
}

functions.http('plugin', async (req, res) => {
  try {
    await loadEnvOnce()
    const response = await getApp().fetch(toRequest(req))
    res.status(response.status)
    response.headers.forEach((value, key) => res.setHeader(key, value))
    res.end(Buffer.from(await response.arrayBuffer()))
  } catch (err) {
    // eslint-disable-next-line no-console
    console.error('StreamForce plugin (gcp) error:', err)
    res.status(500).json({ error: 'plugin invocation failed' })
  }
})
